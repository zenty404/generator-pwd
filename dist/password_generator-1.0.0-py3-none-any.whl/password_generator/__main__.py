from password_generator import generator_window

generator_window.app()

