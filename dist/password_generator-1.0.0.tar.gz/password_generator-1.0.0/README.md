# Password Generator

## Overview

TODO Describe what **Password Generator** does.

## Pre-requisite

1. Install [build](https://path/to/build) module

## Building

```bash
$ python3 -m build
```

## Install

```bash
$ pip3 install dist/password_generator-1.0.0.tar.gz  --force-reinstall
```

## Running

```bash
$ python3 -m password_generator 
```